/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package packingstaff;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/packingform")
public class packingstaff extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String job_title = request.getParameter("job_title");
        String department = request.getParameter("department");
        String hire_date = request.getParameter("hire_date");
        String salary = request.getParameter("salary");

        String url = "jdbc:mysql://localhost:3306/medical";
        String uname = "root";
        String password = "29012002";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, uname, password);

            String sql = "Insert into packing_staff(name, job_title, department, hire_date, salary) VALUES (?,?,?,?,?)";
            String result = "data inserted Successfully";

            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, name);
            st.setString(2, job_title);
            st.setString(3, department);
            st.setString(4, hire_date);
            st.setString(5, salary);
            st.executeUpdate();

            response.sendRedirect("Packingstaffdetails.jsp");
            st.close();
            con.close();

        } catch (Exception e) {
            System.out.println("Error: " + e);
        }
    }
}

