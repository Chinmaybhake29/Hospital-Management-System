/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package stock;

/**
 *
 * @author CHINMAY
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/stockform")
public class stock extends HttpServlet
{
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
        String ProductName=request.getParameter("ProductName");
        String ExpiryDate=request.getParameter("ExpiryDate");
        String VendorDetails=request.getParameter("VendorDetails");
        String Quantity=request.getParameter("Quantity");
        String DateOfManufacturing=request.getParameter("DateOfManufacturing");
        
        String url = "jdbc:mysql://localhost:3306/medical";
        String uname = "root";
        String password = "29012002";
        
        try {
             Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, uname, password);
            String sql="insert into stockdetails(ProductName, ExpiryDate, VendorDetails, Quantity, DateOfManufacturing)values(?,?,?,?,?)";
            String result="Data Inserted Successfully";
            
            PreparedStatement ps=con.prepareStatement(sql);
            ps.setString(1, ProductName);
			ps.setString(2, ExpiryDate);
			ps.setString(3, VendorDetails);
			ps.setString(4, Quantity);
			ps.setString(5, DateOfManufacturing);
			ps.executeUpdate();
                        
                        response.sendRedirect("Stockdetails.jsp");
            ps.close();
            con.close();
        } catch (Exception e) {
            System.out.println("Error: " + e);
        }
    }
}
