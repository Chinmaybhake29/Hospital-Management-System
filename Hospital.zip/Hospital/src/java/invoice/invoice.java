/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package invoice;

/**
 *
 * @author CHINMAY
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/invoiceform")
public class invoice extends HttpServlet
{
     protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
     {
        String customer_name=request.getParameter("customer_name");
        String customer_id=request.getParameter("customer_id");
        String Productname=request.getParameter("Productname");
        String quantity=request.getParameter("quantity");
        String price=request.getParameter("price");
        String total_amount=request.getParameter("quantity") + request.getParameter("price");
         
        String url = "jdbc:mysql://localhost:3306/medical";
        String uname = "root";
        String password = "29012002";
        
         try {
             Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, uname, password);
            
            String sql="insert into invoice(customer_name, customer_id, Productname, quantity, price, total_amount)values(?,?,?,?,?,?)";
            String result = "data inserted Successfully";
            int quantity1 = Integer.parseInt(quantity);
            double price1 = Double.parseDouble(price);
            double totalAmount = quantity1 * price1;
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, customer_name);
            st.setString(2, customer_id);
            st.setString(3, Productname);
            st.setString(4, quantity);
            st.setString(5, price);
            st.setString(6, total_amount);
            st.executeUpdate();
            
          response.sendRedirect("Invoicedetails.jsp");
            st.close();
            con.close();
        } catch (Exception e) {
             System.out.println("Error: " + e);
        }
     }   
}
