/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package newvendor;

/**
 *
 * @author CHINMAY
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/vendorform")
public class newvendor extends HttpServlet
{
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
        String vendor_name=request.getParameter("vendor_name");
        String contact_name=request.getParameter("contact_name");
        String contact_email=request.getParameter("contact_email");
        String contact_phone=request.getParameter("contact_phone");
        String address=request.getParameter("address");
        String city=request.getParameter("city");
        String state_province=request.getParameter("state_province");
        String country=request.getParameter("country");
        String postal_code=request.getParameter("postal_code");
        
        String url = "jdbc:mysql://localhost:3306/medical";
        String uname = "root";
        String password = "29012002";
        
        try {
             Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, uname, password);
            
            String sql="insert into newvendors(vendor_name, contact_name, contact_email, contact_phone, address, city, state_province, country, postal_code)values(?,?,?,?,?,?,?,?,?)";
            String result = "data inserted Successfully";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, vendor_name);
            st.setString(2, contact_name);
            st.setString(3, contact_email);
            st.setString(4, contact_phone);
            st.setString(5, address);
            st.setString(6,city);
            st.setString(7, state_province);
            st.setString(8, country);
            st.setString(9, postal_code);
            st.executeUpdate();

            response.sendRedirect("Newvendordetails.jsp");
            st.close();
            con.close();
            
        } catch (Exception e) {
            System.out.println("Error: " + e);
        }
                
    }
}
