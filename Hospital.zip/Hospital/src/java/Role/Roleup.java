/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Role;

/**
 *
 * @author CHINMAY
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/roleupdate")
public class Roleup extends HttpServlet
{
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
        String name=request.getParameter("name");
        String role_assign=request.getParameter("role_assign");
         
        String role_id=request.getParameter("role_id");
        String url = "jdbc:mysql://localhost:3306/medical";
        String uname = "root";
        String password = "29012002";
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, uname, password);
            String sql="update role set name=?, role_assign=? where role_id=" + role_id;
            String result = "data update Successfully";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, name);
            st.setString(2, role_assign);
            int i=st.executeUpdate();
            { 
            response.sendRedirect("Roleassigndetails.jsp");
            }
            st.close();
            con.close();
        } catch (Exception e) {
             System.out.println("Error: " + e);
        }
    }
}
