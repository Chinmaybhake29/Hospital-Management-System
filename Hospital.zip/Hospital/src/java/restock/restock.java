/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package restock;

/**
 *
 * @author CHINMAY
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/restockD")

public class restock extends HttpServlet
{
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
        String vendors=request.getParameter("vendors");
        String payment_terms=request.getParameter("payment_terms");
        String delivery_time=request.getParameter("delivery_time");
        String delivery_date=request.getParameter("delivery_date");
        
        String url = "jdbc:mysql://localhost:3306/medical";
        String uname = "root";
        String password = "29012002";
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, uname, password);
            
            String sql="Insert into restock(vendors, payment_terms, delivery_time, delivery_date) values (?,?,?,?)";
            String result = "data inserted Successfully";
            
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, vendors);
            st.setString(2, payment_terms);
            st.setString(3, delivery_time);
            st.setString(4, delivery_date);
            st.executeUpdate();

            response.sendRedirect("Restockdetails.jsp");
            st.close();
            con.close();
        } catch (Exception e) {
            System.out.println("Error: " + e);
        }
    }
}
