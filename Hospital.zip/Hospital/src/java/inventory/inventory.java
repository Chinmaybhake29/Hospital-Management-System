/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inventory;

/**
 *
 * @author CHINMAY
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/invenform")
public class inventory extends HttpServlet{
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      String item_name = request.getParameter("item_name");
      String description = request.getParameter("description");
      String quantity=request.getParameter("quantity");
      String unit=request.getParameter("unit");
      String expiration_date=request.getParameter("expiration_date");
      String location=request.getParameter("location");
      String manufacturer=request.getParameter("manufacturer");
      
      String url = "jdbc:mysql://localhost:3306/medical";
        String uname = "root";
        String password = "29012002";
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, uname, password);
            
            String sql="insert into inventory(item_name, description, quantity, unit, expiration_date, location, manufacturer)values(?,?,?,?,?,?,?)";
            String result = "data inserted Successfully";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, item_name);
            st.setString(2, description);
            st.setString(3, quantity);
            st.setString(4, unit);
            st.setString(5, expiration_date);
            st.setString(6, location);
            st.setString(7, manufacturer);
            st.executeUpdate();

            response.sendRedirect("Inventorydetails.jsp");
            st.close();
            con.close();
        } catch (Exception e) {
             System.out.println("Error: " + e);
        }

    }
}