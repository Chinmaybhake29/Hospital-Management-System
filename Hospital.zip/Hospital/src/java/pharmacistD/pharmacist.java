/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pharmacistD;

/**
 *
 * @author CHINMAY
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/pharmacistD")

public class pharmacist extends HttpServlet
{
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
        String first_name=request.getParameter("first_name");
        String last_name=request.getParameter("last_name");
        String email=request.getParameter("email");
        String phone_number=request.getParameter("phone_number");
        String address=request.getParameter("address");
        String date_of_birth=request.getParameter("date_of_birth");
        String date_of_hire=request.getParameter("date_of_hire");
        String salary=request.getParameter("salary");
        
        String url = "jdbc:mysql://localhost:3306/pharmacistDB";
        String uname = "root";
        String password = "29012002";
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, uname, password);
            
            String sql="Insert into pharmacist(first_name, last_name, email, phone_number, address, date_of_birth, date_of_hire, salary) VALUES (?,?,?,?,?,?,?,?)";
            String result = "data inserted Successfully";
            
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, first_name);
            st.setString(2, last_name);
            st.setString(3, email);
            st.setString(4, phone_number);
            st.setString(5, address);
            st.setString(6, date_of_birth);
            st.setString(7, date_of_hire);
            st.setString(8, salary);
            st.executeUpdate();

            response.sendRedirect("Pharmacistdetails.jsp");
            st.close();
            con.close();
        } catch (Exception e) {
            System.out.println("Error: " + e);
        }
    }
}
