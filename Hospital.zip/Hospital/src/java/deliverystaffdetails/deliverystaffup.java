/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package deliverystaffdetails;

/**
 *
 * @author CHINMAY
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/deliverystaffupdate")
public class deliverystaffup extends HttpServlet
{
     protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
     {
        String Name=request.getParameter("Name");
        String ContactInformation=request.getParameter("ContactInformation");
        String Email=request.getParameter("Email");
        String VehicleInformation=request.getParameter("VehicleInformation");
        String Address=request.getParameter("Address");
        String city=request.getParameter("city");
        String state=request.getParameter("state");
        String postal_code=request.getParameter("postal_code");
        String hire_date=request.getParameter("hire_date");
        String active=request.getParameter("active");
        
        String EmployeeID=request.getParameter("EmployeeID");
        String url = "jdbc:mysql://localhost:3306/medical";
        String uname = "root";
        String password = "29012002";
        
         try {
             Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, uname, password);
            String sql="update deliverystaff set Name=?, ContactInformation=?, Email=?, VehicleInformation=?, Address=? city=? state=? postal_code=? active=? where EmployeeID="+EmployeeID;
            String result = "data update Successfully";
            PreparedStatement ps=con.prepareStatement(sql);
            ps.setString(1, Name);
            ps.setString(2, ContactInformation);
            ps.setString(3, Email);
            ps.setString(4, VehicleInformation);
            ps.setString(5, Address);
            ps.setString(6, city);
            ps.setString(7, state);
            ps.setString(8, postal_code);
            ps.setString(9, hire_date);
            ps.setString(10, active);
            int i=ps.executeUpdate();
            { 
            response.sendRedirect("DeliveryStaffdetails.jsp");
            }
            ps.close();
            con.close();
         } catch (Exception e) {
         }
     }
}
